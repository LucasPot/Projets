import javax.swing.*;
import java.awt.*;

/**
 * La classe <code>Main</code> est utilisée pour lancer l'application.
 *  
 * @version 1.1
 * @author Lucas POT & Maxime ELIOT
 */
public class Main {
	/**
	 * methode main d'initialisation de l'application
	 * @param args à qui on envoit rien*/
    public static void main (String [] args){
	Menu.afficherMenu();
    }
}
				   
